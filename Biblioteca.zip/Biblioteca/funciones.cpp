#include <iostream>
#include <fstream>
#include "publicaciones.h"
using namespace std;

void registrar(Publicacion &p) {
    cout << "Codigo: ";
    cin >> p.codigo;
    cout << "Titulo: ";
    cin.ignore();
    
    getline(cin, p.titulo);
    cout << "Anio de publicacion: ";
    cin >> p.anio;
    cout << "Tipo (Libro/Revista): ";
    cin >> p.tipo;
    p.estado = "No Prestado";
}

void prestar(Publicacion &p) {
    p.estado = "Prestado";
}

void devolver(Publicacion &p) {
    p.estado = "No Prestado";
}

void mostrar(Publicacion p) {
    cout << "Codigo: " << p.codigo << endl;
    cout << "Titulo: " << p.titulo << endl;
    cout << "Anio: " << p.anio << endl;

    if (p.estado == "Prestado")
        cout << "Estado: PRESTADO" << endl;
    else
        cout << "Estado: NO PRESTADO" << endl;

    cout << "----------------------" << endl;
}


void guardarArchivos(Publicacion v[], int n) {
    ofstream prestados("LibrosPrestados.txt");
    ofstream stock("LibrosEnStock.txt");

    for (int i = 0; i < n; i++) {
        if (v[i].estado == "Prestado")
            prestados << v[i].codigo << " " << v[i].titulo << " "
                      << v[i].anio << " " << v[i].estado << endl;
        else
            stock << v[i].codigo << " " << v[i].titulo << " "
                  << v[i].anio << " " << v[i].estado << endl;
    }

    prestados.close();
    stock.close();
}
