#include <iostream>
#include "publicaciones.h"
using namespace std;

void registrar(Publicacion &p);
void prestar(Publicacion &p);
void devolver(Publicacion &p);
void mostrar(Publicacion p);
void guardarArchivos(Publicacion v[], int n);

int main() {
    int n;
    cout << "Cuantas publicaciones desea ingresar: ";
    cin >> n;

    Publicacion publicaciones[n];

    for (int i = 0; i < n; i++) {
        cout << "\nRegistro " << i + 1 << endl;
        registrar(publicaciones[i]);
    }

    if (n > 0) {
        prestar(publicaciones[0]);
    }

    cout << "\nPublicaciones registradas:\n";
    for (int i = 0; i < n; i++) {
        mostrar(publicaciones[i]);
    }

    guardarArchivos(publicaciones, n);

    cout << "\nArchivos creados correctamente.\n";
    return 0;
}
