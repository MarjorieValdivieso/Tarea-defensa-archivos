#ifndef PUBLICACIONES_H
#define PUBLICACIONES_H

#include <string>
using namespace std;

struct Publicacion {
    int codigo;
    string titulo;
    int anio;
    string tipo;
    string estado;
};

#endif
