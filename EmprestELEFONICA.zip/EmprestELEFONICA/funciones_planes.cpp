#include <iostream>
#include <fstream>
#include <string>
#include "estructuras.h"
using namespace std;

void guardarPlanes(Plan planes[], int n) {
    ofstream archivo("planes.txt");
    for(int i=0;i<n;i++){
        archivo << planes[i].codigo << ","
                << planes[i].nombre << ","
                << planes[i].velocidadMinutos << ","
                << planes[i].precio << endl;
    }
    archivo.close();
}

int cargarPlanes(Plan planes[]) {
    ifstream archivo("planes.txt");
    int i = 0;
    while(archivo >> planes[i].codigo){
        archivo.ignore();
        getline(archivo, planes[i].nombre, ',');
        archivo >> planes[i].velocidadMinutos;
        archivo.ignore();
        archivo >> planes[i].precio;
        i++;
    }
    archivo.close();
    return i;
}

void mostrarPlanes(Plan planes[], int n){
    cout << "\n==== PLANES DISPONIBLES ====\n";
    for(int i=0;i<n;i++){
        cout << "Codigo: " << planes[i].codigo
             << " | Nombre: " << planes[i].nombre
             << " | Vel/Min: " << planes[i].velocidadMinutos
             << " | Precio: $" << planes[i].precio << endl;
    }
}
