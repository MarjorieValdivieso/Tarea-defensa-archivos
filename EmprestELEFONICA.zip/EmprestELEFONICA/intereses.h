#ifndef INTERESES_H
#define INTERESES_H

#include <fstream>
#include <string>
using namespace std;

void calcularInteres(string nombre, double capital){
    double interes = capital * 0.15;
    double total = capital + interes;

    ofstream archivo("intereses.txt");

    archivo << "Cliente: " << nombre << endl;
    archivo << "Capital: " << capital << endl;
    archivo << "Interes 15%: " << interes << endl;
    archivo << "Total a pagar: " << total << endl;

    archivo.close();
}

#endif


