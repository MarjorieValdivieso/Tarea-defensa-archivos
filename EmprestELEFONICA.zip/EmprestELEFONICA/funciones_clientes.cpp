#include <iostream>
#include <fstream>
#include <string>
#include "estructuras.h"
using namespace std;

void guardarClientes(Cliente clientes[], int n){
    ofstream archivo("clientes.txt");
    for(int i=0;i<n;i++){
        archivo << clientes[i].codigo << ","
                << clientes[i].nombre << ","
                << clientes[i].tipoServicio << ","
                << clientes[i].anioAfiliacion << ","
                << clientes[i].estado << ","
                << clientes[i].mesesSuspendido << ","
                << clientes[i].codigoPlan << endl;
    }
    archivo.close();
}

int cargarClientes(Cliente clientes[]){
    ifstream archivo("clientes.txt");
    int i = 0;
    while(archivo >> clientes[i].codigo){
        archivo.ignore();
        getline(archivo, clientes[i].nombre, ',');
        getline(archivo, clientes[i].tipoServicio, ',');
        archivo >> clientes[i].anioAfiliacion;
        archivo.ignore();
        getline(archivo, clientes[i].estado, ',');
        archivo >> clientes[i].mesesSuspendido;
        archivo.ignore();
        archivo >> clientes[i].codigoPlan;
        i++;
    }
    archivo.close();
    return i;
}

void mostrarClientes(Cliente clientes[], int n){
    cout << "\n==== LISTADO DE CLIENTES ====\n";
    for(int i=0;i<n;i++){
        cout << "Codigo: " << clientes[i].codigo
             << " | Nombre: " << clientes[i].nombre
             << " | Servicio: " << clientes[i].tipoServicio
             << " | Estado: " << clientes[i].estado
             << " | Plan: " << clientes[i].codigoPlan << endl;
    }
}

void actualizarSuspendidos(Cliente clientes[], int n){
    for(int i=0;i<n;i++){
        if(clientes[i].estado == "Suspendido" &&
           clientes[i].mesesSuspendido > 3){
            clientes[i].estado = "Cancelado";
        }
    }
}
