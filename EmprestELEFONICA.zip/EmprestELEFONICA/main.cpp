#include <iostream>
#include <fstream>
#include <string>
#include "estructuras.h"
#include "intereses.h"
using namespace std;

// Declaraciones de funciones
void guardarClientes(Cliente[], int);
int cargarClientes(Cliente[]);
void mostrarClientes(Cliente[], int);
void actualizarSuspendidos(Cliente[], int);

void guardarPlanes(Plan[], int);
int cargarPlanes(Plan[]);
void mostrarPlanes(Plan[], int);

int main(){
    Cliente clientes[20];
    Plan planes[10];

    int numClientes = cargarClientes(clientes);
    int numPlanes = cargarPlanes(planes);

    int opcion;
    do{
        cout << "\n===== MENU PRINCIPAL =====\n";
        cout << "1. Registrar cliente\n";
        cout << "2. Mostrar clientes\n";
        cout << "3. Mostrar planes\n";
        cout << "4. Actualizar suspendidos -> cancelados\n";
        cout << "5. Generar facturacion.txt\n";
        cout << "6. Calcular interes de prestamo\n";
        cout << "0. Salir\n";
        cout << "Seleccione: ";
        cin >> opcion;

        if(opcion == 1){
            Cliente c;
            cout << "Codigo: "; cin >> c.codigo;
            cin.ignore();
            cout << "Nombre: "; getline(cin, c.nombre);
            cout << "Tipo (Internet/Telefonia/Combo): ";
            getline(cin, c.tipoServicio);
            cout << "Anio afiliacion: "; cin >> c.anioAfiliacion;
            c.estado = "Activo";
            c.mesesSuspendido = 0;
            cout << "Codigo de plan: "; cin >> c.codigoPlan;

            clientes[numClientes] = c;
            numClientes++;
            guardarClientes(clientes, numClientes);
            cout << "Cliente guardado correctamente!\n";
        }

        if(opcion == 2){
            mostrarClientes(clientes, numClientes);
        }

        if(opcion == 3){
            mostrarPlanes(planes, numPlanes);
        }

        if(opcion == 4){
            actualizarSuspendidos(clientes, numClientes);
            guardarClientes(clientes, numClientes);
            cout << "Estados actualizados!\n";
        }

        if(opcion == 5){
            ofstream factura("facturacion.txt");
            factura << "Codigo,Nombre,Precio,Total\n";

            double totalFacturado = 0;

            for(int i=0;i<numClientes;i++){
                double precio = 0;
                for(int j=0;j<numPlanes;j++){
                    if(clientes[i].codigoPlan == planes[j].codigo){
                        precio = planes[j].precio;
                    }
                }
                factura << clientes[i].codigo << ","
                        << clientes[i].nombre << ","
                        << precio << ","
                        << precio << endl;
                totalFacturado += precio;
            }

            factura.close();
            cout << "Archivo facturacion.txt generado!\n";
            cout << "Total facturado: $" << totalFacturado << endl;
        }

        if(opcion == 6){
            string nombre;
            double capital;

            cin.ignore();
            cout << "Nombre del cliente: ";
            getline(cin, nombre);
            cout << "Capital del prestamo: ";
            cin >> capital;

            calcularInteres(nombre, capital);
            cout << "Archivo intereses.txt generado!\n";
        }

    }while(opcion != 0);

    return 0;
}

