#ifndef ESTRUCTURAS_H
#define ESTRUCTURAS_H

#include <string>
using namespace std;

struct Cliente {
    int codigo;
    string nombre;
    string tipoServicio;   
    int anioAfiliacion;
    string estado;         
    int mesesSuspendido;   
    int codigoPlan;
};

struct Plan {
    int codigo;
    string nombre;
    int velocidadMinutos;  
    double precio;
};

#endif
